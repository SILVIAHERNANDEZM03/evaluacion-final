package com.example.aplicacionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class actividad27 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad27)
    }
    fun sopaminestrone(view: View) {
        val intent = Intent(this, actividad6()::class.java)
        startActivity(intent)
    }
    fun ordenes(view: View) {
        val intent = Intent(this, actividad60()::class.java)
        startActivity(intent)
    }
}