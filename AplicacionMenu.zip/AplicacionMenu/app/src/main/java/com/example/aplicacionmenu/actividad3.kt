package com.example.aplicacionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View


class actividad3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad3)
    }

    fun actividadmenu(view: View) {
        val intent = Intent(this, MainActivity()::class.java)
        startActivity(intent)
    }

    fun comidaMexicana(view: View) {
        val intent = Intent(this, actividad4()::class.java)
        startActivity(intent)
    }

    fun comidaChina(view: View) {
        val intent = Intent(this, actividad5()::class.java)
        startActivity(intent)
    }

    fun comidaItaliana(view: View) {
        val intent = Intent(this, actividad6()::class.java)
        startActivity(intent)
    }

    fun comidaCoreana(view: View) {
        val intent = Intent(this, actividad7()::class.java)
        startActivity(intent)
    }

    fun comidaEstadounidense(view: View) {
        val intent = Intent(this, actividad8()::class.java)
        startActivity(intent)
    }

    fun bebidas(view: View) {
        val intent = Intent(this, actividad10()::class.java)
        startActivity(intent)
    }

    fun vinosylicores(view: View) {
        val intent = Intent(this, actividad11()::class.java)
        startActivity(intent)
    }
    fun postres(view: View) {
        val intent = Intent(this, actividad12()::class.java)
        startActivity(intent)
    }
}