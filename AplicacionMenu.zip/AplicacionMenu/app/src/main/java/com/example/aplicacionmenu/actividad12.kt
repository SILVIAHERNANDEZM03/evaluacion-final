package com.example.aplicacionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class actividad12 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad12)
    }
    fun postres(view: View) {
        val intent = Intent(this, actividad3()::class.java)
        startActivity(intent)
    }
    fun macarrones(view: View) {
        val intent = Intent(this, actividad54()::class.java)
        startActivity(intent)
    }
    fun helado(view: View) {
        val intent = Intent(this, actividad55()::class.java)
        startActivity(intent)
    }
    fun brownies(view: View) {
        val intent = Intent(this, actividad56()::class.java)
        startActivity(intent)
    }
    fun trufas(view: View) {
        val intent = Intent(this, actividad57()::class.java)
        startActivity(intent)
    }
    fun pay(view: View) {
        val intent = Intent(this, actividad58()::class.java)
        startActivity(intent)
    }
    fun ensaladademanzana(view: View) {
        val intent = Intent(this, actividad59()::class.java)
        startActivity(intent)
    }
}