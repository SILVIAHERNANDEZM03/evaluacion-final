package com.example.aplicacionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class actividad10 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad10)
    }
    fun bebidas(view: View) {
        val intent = Intent(this, actividad3()::class.java)
        startActivity(intent)
    }
    fun limonada(view: View) {
        val intent = Intent(this, actividad42()::class.java)
        startActivity(intent)
    }
    fun Aguadecoco(view: View) {
        val intent = Intent(this, actividad43()::class.java)
        startActivity(intent)
    }
    fun Aguadehorchata(view: View) {
        val intent = Intent(this, actividad44()::class.java)
        startActivity(intent)
    }
    fun Aguadeguanabana(view: View) {
        val intent = Intent(this, actividad45()::class.java)
        startActivity(intent)
    }
    fun sprite(view: View) {
        val intent = Intent(this, actividad46()::class.java)
        startActivity(intent)
    }
    fun coca(view: View) {
        val intent = Intent(this, actividad47()::class.java)
        startActivity(intent)
    }
}