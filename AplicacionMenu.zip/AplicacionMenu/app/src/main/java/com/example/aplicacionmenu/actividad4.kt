package com.example.aplicacionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class actividad4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad4)
    }
    fun comidaMexicana(view: View) {
        val intent = Intent(this, actividad3()::class.java)
        startActivity(intent)
    }
    fun mole(view: View) {
        val intent = Intent(this, actividad9()::class.java)
        startActivity(intent)
    }
    fun pozole(view: View) {
        val intent = Intent(this, actividad13()::class.java)
        startActivity(intent)
    }
    fun cochinitapibil(view: View) {
        val intent = Intent(this, actividad14()::class.java)
        startActivity(intent)
    }
    fun chilesNogada(view: View) {
        val intent = Intent(this, actividad15()::class.java)
        startActivity(intent)
    }
    fun tlayudas(view: View) {
        val intent = Intent(this, actividad16()::class.java)
        startActivity(intent)
    }
    fun tacos(view: View) {
        val intent = Intent(this, actividad17()::class.java)
        startActivity(intent)
    }
}