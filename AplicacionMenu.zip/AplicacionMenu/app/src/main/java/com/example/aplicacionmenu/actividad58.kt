package com.example.aplicacionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class actividad58 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad58)
    }
    fun pay(view: View) {
        val intent = Intent(this, actividad12()::class.java)
        startActivity(intent)
    }
    fun ordenes(view: View) {
        val intent = Intent(this, actividad60()::class.java)
        startActivity(intent)
    }
}