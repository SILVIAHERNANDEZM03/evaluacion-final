package com.example.aplicacionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class actividad6 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad6)
    }
    fun comidaItaliana(view: View) {
        val intent = Intent(this, actividad3()::class.java)
        startActivity(intent)
    }
    fun lasana(view: View) {
        val intent = Intent(this, actividad24()::class.java)
        startActivity(intent)
    }
    fun risotto(view: View) {
        val intent = Intent(this, actividad25()::class.java)
        startActivity(intent)
    }
    fun Carpaccio(view: View) {
        val intent = Intent(this, actividad26()::class.java)
        startActivity(intent)
    }
    fun sopaminestrone(view: View) {
        val intent = Intent(this, actividad27()::class.java)
        startActivity(intent)
    }
    fun Ossobuco(view: View) {
        val intent = Intent(this, actividad28()::class.java)
        startActivity(intent)
    }
    fun ensaladacapresse(view: View) {
        val intent = Intent(this, actividad29()::class.java)
        startActivity(intent)
    }
}