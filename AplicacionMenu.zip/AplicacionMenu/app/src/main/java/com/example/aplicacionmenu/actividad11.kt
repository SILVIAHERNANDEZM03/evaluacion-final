package com.example.aplicacionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class actividad11 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad11)
    }
    fun vinosylicores(view: View) {
        val intent = Intent(this, actividad3()::class.java)
        startActivity(intent)
    }
    fun vinoTinto(view: View) {
        val intent = Intent(this, actividad48()::class.java)
        startActivity(intent)
    }
    fun vinoBlanco(view: View) {
        val intent = Intent(this, actividad49()::class.java)
        startActivity(intent)
    }
    fun tequila(view: View) {
        val intent = Intent(this, actividad50()::class.java)
        startActivity(intent)
    }
    fun whisky(view: View) {
        val intent = Intent(this, actividad51()::class.java)
        startActivity(intent)
    }
    fun CervezaOscura(view: View) {
        val intent = Intent(this, actividad52()::class.java)
        startActivity(intent)
    }
    fun CervezaUltra(view: View) {
        val intent = Intent(this, actividad53()::class.java)
        startActivity(intent)
    }
}