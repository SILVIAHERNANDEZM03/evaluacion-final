package com.example.aplicacionmenu

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun actividadregistro(view: View) {
        val intent = Intent(this, actividad2()::class.java)
        startActivity(intent)
    }
    fun actividadmenu(view: View) {
        val intent = Intent(this, actividad3()::class.java)
        startActivity(intent)
    }

    fun Instag(view: View) {
        val message: String? = null
        val url = "https://www.instagram.com/hotel_xalla/"
        val i = Intent(Intent.ACTION_VIEW)
        i.data = Uri.parse(url)
        startActivity(i)

        fun isAppInstalled(packageName: String, context: Context): Boolean {
            return try {
                val packageManager = context.packageManager
                packageManager.getPackageInfo(packageName, 0)
                true
            } catch (e: PackageManager.NameNotFoundException) {
                false
            }
        }
    }
    fun Facebook(view: View) {
        val message: String? = null
        val url = "https://www.facebook.com/profile.php?id=100076331212951"
        val i = Intent(Intent.ACTION_VIEW)
        i.data = Uri.parse(url)
        startActivity(i)

        fun isAppInstalled(packageName: String, context: Context): Boolean {
            return try {
                val packageManager = context.packageManager
                packageManager.getPackageInfo(packageName, 0)
                true
            } catch (e: PackageManager.NameNotFoundException) {
                false
            }
        }
    }
    override fun onStart() {
        super.onStart()
        val toast = Toast.makeText(applicationContext, "Bienvenido al menú", Toast.LENGTH_SHORT)
        toast.show()
    }

    override fun onRestart() {
        super.onRestart()
        val toast = Toast.makeText(applicationContext, "onRestart", Toast.LENGTH_SHORT)
        toast.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        val toast = Toast.makeText(applicationContext, "Disfrute su pedido", Toast.LENGTH_SHORT)
        toast.show()
    }
}