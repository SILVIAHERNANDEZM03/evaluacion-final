package com.example.aplicacionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class actividad8 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad8)
    }

    fun comidaEstadounidense(view: View) {
        val intent = Intent(this, actividad3()::class.java)
        startActivity(intent)
    }

    fun costillas(view: View) {
        val intent = Intent(this, actividad36()::class.java)
        startActivity(intent)
    }

    fun pizza(view: View) {
        val intent = Intent(this, actividad37()::class.java)
        startActivity(intent)
    }

    fun hamburguesa(view: View) {
        val intent = Intent(this, actividad38()::class.java)
        startActivity(intent)
    }
    fun MacarronesConQueso(view: View) {
        val intent = Intent(this, actividad39()::class.java)
        startActivity(intent)
    }
    fun alitas(view: View) {
        val intent = Intent(this, actividad40()::class.java)
        startActivity(intent)
    }
    fun ensalada(view: View) {
        val intent = Intent(this, actividad41()::class.java)
        startActivity(intent)
    }
}