package com.example.aplicacionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class actividad7 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad7)
    }
    fun comidaCoreana(view: View) {
        val intent = Intent(this, actividad3()::class.java)
        startActivity(intent)
    }
    fun Bulgogi(view: View) {
        val intent = Intent(this, actividad30()::class.java)
        startActivity(intent)
    }
    fun kimchi(view: View) {
        val intent = Intent(this, actividad31()::class.java)
        startActivity(intent)
    }
    fun bibimbap(view: View) {
        val intent = Intent(this, actividad32()::class.java)
        startActivity(intent)
    }
    fun gimbap(view: View) {
        val intent = Intent(this, actividad33()::class.java)
        startActivity(intent)
    }
    fun galbitang(view: View) {
        val intent = Intent(this, actividad34()::class.java)
        startActivity(intent)
    }
    fun banchan(view: View) {
        val intent = Intent(this, actividad35()::class.java)
        startActivity(intent)
    }
}