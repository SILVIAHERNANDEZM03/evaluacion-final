package com.example.aplicacionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class actividad60 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad60)
    }
    fun menuprincipal(view: View) {
        val intent = Intent(this, actividad3()::class.java)
        startActivity(intent)
    }

}