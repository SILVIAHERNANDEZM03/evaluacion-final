package com.example.aplicacionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class actividad5 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad5)
    }
    fun comidaChina(view: View) {
        val intent = Intent(this, actividad3()::class.java)
        startActivity(intent)
    }
    fun pato(view: View) {
        val intent = Intent(this, actividad18()::class.java)
        startActivity(intent)
    }
    fun sopaWantan(view: View) {
        val intent = Intent(this, actividad19()::class.java)
        startActivity(intent)
    }
    fun MapoDoufu(view: View) {
        val intent = Intent(this, actividad20()::class.java)
        startActivity(intent)
    }
    fun rollito(view: View) {
        val intent = Intent(this, actividad21()::class.java)
        startActivity(intent)
    }
    fun Zongzi(view: View) {
        val intent = Intent(this, actividad22()::class.java)
        startActivity(intent)
    }
    fun PolloGongBao(view: View) {
        val intent = Intent(this, actividad23()::class.java)
        startActivity(intent)
    }
}